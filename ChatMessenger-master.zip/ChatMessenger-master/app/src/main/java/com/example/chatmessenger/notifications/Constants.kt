package com.example.chatmessenger.notifications

class Constants {
    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "{inserserverkey}"
        const val CONTENT_TYPE = "application/json"
    }
}
